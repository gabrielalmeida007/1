const help = (prefix) => {
	return `
╔══✪〘 INFO 〙✪══
║
╠➥ FRIBOI 𝐁𝐎𝐓
╠➥ *3.2*
╠➥ 𝐃𝐎𝐍𝐎:  ғᷫʀᷢɪͥʙᷨᴏͦɪͥ ⃘⃤🐊
╠➥ *wa.me/+5515998576105*
╠➥ 𝐒𝐓𝐀𝐓𝐔𝐒: ON
║
╠══✪〘 NOVIDADES 〙✪══
║
║1 *${prefix}animecry*
║2 *${prefix}chentai [premium]*
║3 *${prefix}gcpf [premium]*
║4 *${prefix}gay [@]*
║5 *${prefix}gbin [premium]*
║5 *${prefix}pack [premium]*
║6 *${prefix}destrava [premium]*
║7 *${prefix}gpessoa [premium]*
║8 *${prefix}wame*
║9 *${prefix}spamcall*
║10 *${prefix}play (nome da msc)*
║
╠══✪〘 MENU 〙✪══
║
║11 *${prefix}sticker*
║12 *${prefix}toimg*
║13 *${prefix}darkjokes (memes aleatórios)*
║14 *${prefix}memeindo*
║15 *${prefix}tts*
║16 *${prefix}lolih [on]*
║17 *${prefix}nsfwloli [off]*
║18 *${prefix}url2img*
║19 *${prefix}leens [na legenda]*
║20 *${prefix}wait [na legenda]*
║21 *${prefix}setprefix*
║
╠══✪〘 OUTROS 〙✪══
║
║22 *${prefix}linkgp*
║23 *${prefix}simih [1/0]*
║24 *${prefix}marcar*
║25 *${prefix}add [@]*
║26 *${prefix}banir [@]*
║27 *${prefix}promover [@]*
║28 *${prefix}rebaixar*
║29 *${prefix}admins*
║30 *${prefix}marcar2*
║31 *${prefix}bc [texto]* (ele faz uma ™)
║32 *${prefix}marcar3*
║33 *${prefix}bloqueados*
║34 *${prefix}bloquear [@]*
║35 *${prefix}desbloquear [@]*
║36 *${prefix}limpar*
║37 *${prefix}bc [ *texto* ]*
║38 *${prefix}bemvindo [1/0]*
║39 *${prefix}clonar [@]*
║40 *${prefix}help1*
║41 *${prefix}dono*
║42 *${prefix}owner*
║43 *${prefix}tts [texto]*
║44 *${prefix}setnome*
║45 *${prefix}termux*
║46 *${prefix}setfoto*
║47 *${prefix}grupoinfo*
║48 *${prefix}ytmp4*
║49 *${prefix}bomdia*
║50 *${prefix}boanoite*
║51 *${prefix}marcar*
║52 *${prefix}marcar2*
║53 *${prefix}marcar3*
║
╠══✪〘 IMAGENS 〙✪══
║
║54 *${prefix}loli* [off]
║55 *${prefix}loli1*
║56 *${prefix}hentai*
║57 *${prefix}dono*
║58 *${prefix}porno*
║59 *${prefix}boanoite*
║60 *${prefix}bomdia*
║61 *${prefix}boatarde*
║62 *${prefix}mia [aleatórias]*
║63 *${prefix}rize [aleatórias]*
║64 *${prefix}minato [aleatórias]*
║65 *${prefix}boruto [aleatórias]*
║66 *${prefix}hinata [aleatórias]*
║67 *${prefix}sasuke [aleatórias]*
║68 *${prefix}sakura [aleatórias]*
║69 *${prefix}naruto [aleatórias]*
║70 *${prefix}meme*   
║71 *${prefix}lofi*
║72 *${prefix}malkova*
║73 *${prefix}canal*
║74 *${prefix}nsfwloli1*
║75 *${prefix}reislin*
║
╠══✪〘 INTELIGÊNCIA IA 〙✪══
║
║76 *${prefix}simih 1 (para ativar)*
║77 *${prefix}simih 0 (para desativar)*
║78 *${prefix}*s (msg)*
║79 *${prefix}*speak*
║80 *${prefix}*tesposta*
║
╠══✪〘 EM TESTE 〙✪══
║
║00*${prefix}*waitz
║00 *${prefix}*bot*
║00 *${prefix}*detector*
║00 *${prefix}* 
║00 *${prefix}* 
║00 *${prefix}* 
║00 *${prefix}* 
╠══✪〘 PREMIUM 〙✪══
║
║81 *${prefix}dado*
║82 *${prefix}cekvip*
║83 *${prefix}premiumlist*
║84 *${prefix}delete*
║85 *${prefix}modapk*
║86 *${prefix}indo10*
║87 *${prefix}daftarvip [para virar Premium]*
║88 *${prefix}qrcode*
║89 *${prefix}chentai*
║90 *${prefix}gcpf*
║91 *${prefix}gbin*
║92 *${prefix}pack*
║93 *${prefix}destrava*
║94 *${prefix}gpessoa*
║
╠══✪〘 GRUPO 〙✪══
║
║95 *${prefix}banir*
║96 *${prefix}leveling [on/off]*
║97 *${prefix}level*
║98 *${prefix}add*
║99 *${prefix}promover*
║100 *${prefix}setfoto [na legenda]*
║101 *${prefix}setname [texto]*
║102 *${prefix}rebaixar*
║103 *${prefix}admins*
║104 *${prefix}marcar*
║105 *${prefix}marcar2*
║106 *${prefix}marcar3*
║107 *${prefix}bemvindo [1/0]*
║108 *${prefix}grupoinfo*
║109 *${prefix}bomdia*
║110 *${prefix}boatarde*
║111 *${prefix}boanoite*
║112 *${prefix}setdesc*
║113 *${prefix}bug [sua mensagem]*
║
╠══✪〘 ESPECIFICO DO BOT 〙✪══
║
║114 *${prefix}bug [sua mensagem]*
║115 *${prefix}clonar [@]*
║116 *${prefix}dono*
║117 *${prefix}ping [ver velocidade do bot]*
║118 *${prefix}termux*
║119 *${prefix}gay [@]*
║120 *${prefix}wame*
║121 *${prefix}map (nome)*
║122 *${prefix}setppbot (marque uma img)*
║123 *${prefix}pinterest (nome)*
║124 *${prefix}desligar (so para o dono)*
║125 *${prefix}timer*
║
╠══✪〘 MAIS ALGUNS 〙✪══
║
║126 *${prefix}neko*
║127 *${prefix}ttp [texto]*
║128 *${prefix}testime*
║129 *${prefix}tomp3*
║130 *${prefix}modoanime [on/off]*
║131 *${prefix}modonsfw [on/off]*
║132 *${prefix}happymod [jogo/app]*
║133 *${prefix}rize*
║134 *${prefix}ytsearch*
║135 *${prefix}moddroid [jogo/app]*
║136 *${prefix}xvideos [titulo]**
║137 *${prefix}nomegp*
║138 *${prefix}darkjokes (memes aleatórios)*
║139 *${prefix}animecry*
║140 *${prefix}gay1*
║141 *${prefix}next*
║142 *${prefix}alerta*
║143 *${prefix}belle [img aleatórias]*
║144 *${prefix}pronomeneu [texto]*
║144 *${prefix}hobby*
║
╠══✪〘 COMANDOS DE VOZ 〙✪══
║
║145 *${prefix}ola*
║146 *${prefix}bv*
║147 *${prefix}tchau*
║148 *${prefix}bem*
║149 *${prefix}a*
║150 *${prefix}fdp*
║151 *${prefix}onich*
║152 *${prefix}beat1*
║153 *${prefix}glub*
║
╠══✪〘 OUTROS /2 〙✪══
║
║154 *${prefix}antilink [1/0]*
║155 *${prefix}brainly [pergunta]*
║156 *${prefix}antiracismo [on/off]*
║157 *${prefix}setnomebot*
║158 *${prefix}meme*
║
╠══✪〘 INTERATIVOS 〙✪══
║
╠══NOTA »
║Mandar a msg sem o prefixo
╠════════════════════
║
║159 *bah*
║160 *oii*
║161 *bv*
║162 *canta ai bot*
║163 *grita*
║
╚═〘 FRIBOI 𝐁𝐎𝐓 〙`
}

exports.help = help

